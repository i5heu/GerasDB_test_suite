# wikinota
This is WikiNota - pls. consider this as my personal "hello world"
