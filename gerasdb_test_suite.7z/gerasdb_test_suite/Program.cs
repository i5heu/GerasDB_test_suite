﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

using static gerasdb_test_suite.Itemtest;

namespace gerasdb_test_suite
{
    class Program
    {
        public const string postUrl = "http://localhost:3026/";
        public const string getUrl = "http://localhost:3026/get?id=";
        private static readonly HttpClient client = new HttpClient();

        private static int testCount = 5000;
        static async Task Main()
        {
            Itemtest.client = client;
            for (int i = 0; i < testCount; i++)
            {
                // Multi threading breaks GerasDB
                // Task thread1 = Program.ExecuteTest(i);
                // Task thread2 = Program.ExecuteTest(i);
                // Task.WaitAll(thread1, thread2);

                await Program.ExecuteTest(i);
                // sleep for 10ms so the connection can close so GerasDB dose not panic
                System.Threading.Thread.Sleep(10);
            }
        }
        static async Task ExecuteTest(int i)
        {
            var randomString = Path.GetRandomFileName().Replace(".", "");
            dynamic json = await PostDataToServer(postUrl, randomString);
            GetDataFromServer(getUrl, json);
            Console.Write("\x000DProgress: " + i + "/" + testCount + " HASH:" + json.hash);
        }

    }
}
