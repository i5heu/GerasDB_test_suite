﻿using System;
using System.IO;
using System.Net.Http;

using static gerasdb_test_suite.Itemtest;

namespace gerasdb_test_suite
{
    class Program
    {
        public const string postUrl = "http://localhost:3020/";
        public const string getUrl = "http://localhost:3020/get?id=";
        private static readonly HttpClient client = new HttpClient();
        static void Main()
        {
            Itemtest.client = client;
            for (int i = 0; i < 10000; i++)
            {
                Program.ExecuteTest();
            }
        }
        static async void ExecuteTest()
        {
            var randomString = Path.GetRandomFileName().Replace(".", "");
            var hash = await PostDataToServer(postUrl, randomString);
            GetDataFromServer(getUrl, hash);
        }

    }
}
