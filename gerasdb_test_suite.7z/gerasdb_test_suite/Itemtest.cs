using System;
using System.Net.Http;
using System.Web.Helpers;
using System.Threading.Tasks;

namespace gerasdb_test_suite
{
    static class Itemtest
    {
        public static HttpClient client;
        public async static Task<string> PostDataToServer(String postUrl, String randomString)
        {
            var postData = new StringContent(randomString);
            // client will panic the test if connection error - exit with 1 (so it is usable for testing pipeline)
            var response = await client.PostAsync(postUrl, postData);
            var responseString = await response.Content.ReadAsStringAsync();
            dynamic json  = Json.Decode(responseString);;
            return json.hash;
        }

        public async static void GetDataFromServer(String getUrl, String hash)
        {
            // client will panic the test if connection error - exit with 1 (so it is usable for testing pipeline)
            HttpResponseMessage response = await client.GetAsync(getUrl + hash);
            response.EnsureSuccessStatusCode();
            string responseBody = await response.Content.ReadAsStringAsync();
            if (responseBody.Contains("NOT FOUND")) Console.WriteLine("ERROR: Item not Found with HASH: " + hash);
        }
    }
}
